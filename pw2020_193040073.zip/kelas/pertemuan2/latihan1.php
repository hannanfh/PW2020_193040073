<?php 
//mencetak tulisan ke layar
    echo '<h1>Hello World</h1>';
    echo '<hr>';

    echo (2 + 1) * (3 - 4);
    echo '<hr>';

//Variabel
//tempat menyimpan nilai
$email = 'Hannanfh34385@gmail.com';
echo $email;
echo '<hr>';
//operator
//operator aritmatika
// =,-,*,/,%
echo 10 % 9;
echo '<hr>';

//operator aasigment / penugasan
// =, +=, -=, *=, /=
$x = 1;
$y = 2;
$z = $x;
echo $z;
echo '<hr>';

$a = 1;
$a += 5;
echo $a;
echo '<hr>';

//operatoe increment / decrement
//++, --
$x = 1;
$x++;
$x--;
echo $x;
echo '<hr>';

// operator string / concat / penggabungan string
//.
$nama_depan = 'Hannan';
$nama_tengah ='Fakhrul';
$nama_belakang = 'Hakim';

echo $nama_depan.' '.$nama_tengah. ' '.$nama_belakang;
echo '<hr>';

//standar output
//echo, print
// '', ""
//escape character '/'

$salam = "Assalamu'alaikum";
echo $salam;
$percakapan = "A : \"Assalamu'alaikum\"";
echo $percakapan;














    ?>