<?php
if ($_POST['username'] == 'Hannanfh' && $_POST['password'] == 'hannan') {
    echo '<h1>Selamat datang HANNAN!!!!!!!</h1>';
} else {
    echo '<h1>Username / Password salah cuyy!</h1>';
}

?>