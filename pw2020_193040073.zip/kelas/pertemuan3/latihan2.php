<?php
// For
for ($i =1; $i <=10; $i++) {
echo "Helloo World $i Kali! <br>";


}



?>