<?php
// Pengkondisian / Conditionals
// If

// $angka =100;
// if($angka <10 || $angka >=1) {
// echo "Siaa Benar anjing! <br>";
// } else if ($angka ==25) {
// echo"$angka adalah angka favorit anda! <br>";
// } else {
// echo"Sia Tolol anjing! <br>";
// }

for($angka =1; $angka <=10; $angka++){
if($angka % 2 == 0){
    echo "$angka adalah bilangan Genap! <br>";
} else {
    echo "$angka adalah bilangan Ganjil! <br>";
}
}



?>