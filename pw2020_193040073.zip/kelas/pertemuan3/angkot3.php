<?php

for ($i =1; $i <=10; $i++) {
if ($i <=6){
    echo "Angkot No. $i Beroperasi dengan Baik!!. <br>";
} else {
    echo "Angkot No. $i sedang tidak beroperasi! <br>";
}
    
}



?>