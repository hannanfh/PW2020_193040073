<?php
// Pengulangan
// While
$i =1;
while($i <=10) {
// echo 'Hello Wolrd! '. $i .' kali! <br>';
echo"Hello World $i kali! <br>";
$i++;
}

echo 'Selesai';
echo '<hr>';

$i =10; // Nilai Awal
while($i >=0) { // Kondisi Terminasi
// echo 'Hello Wolrd! '. $i .' kali! <br>';
echo"Hello World $i kali! <br>";
$i--; // increment / decrement
}
echo 'Selesai';

echo '<hr>';


?>