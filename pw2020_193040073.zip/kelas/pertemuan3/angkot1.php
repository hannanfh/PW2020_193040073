<?php

$i =1;
while($i <=10) { 
echo"Angkot No. $i Beroprasi dengan Baik. <br>";
$i++;
}
echo 'Selesai';






?>