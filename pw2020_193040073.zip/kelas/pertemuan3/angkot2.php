<?php

$i =1;
while($i <=6) { 
echo"Angkot No. $i Beroprasi dengan Baik. <br>";
$i++;
}

for ($i =7; $i <=10; $i++) {
    echo "Angkot No. $i sedang tidak beroprasi!. <br>";

}



?>