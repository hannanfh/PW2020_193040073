<?php
$a = "variabel";
$b = "nilai";
echo $a . " menyimpan ".$b.", " .$b." disimpan di".$a;







?>