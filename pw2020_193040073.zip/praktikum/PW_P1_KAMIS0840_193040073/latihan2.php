<?php
$angka = 5;
echo " Aku adalah angka $angka";
echo "<br>";
echo "Jika aku ditambah 20, jumlahku sekarang " . $angka += 20;
echo "<br>";
echo "Jika aku dikali 4, jumlahku sekarang " . $angka *= 4;
echo "<br>";
echo "Jika aku dikurang 10, jumlahku sekarang " . $angka -= 10;
echo "<br>";
echo "Jika aku dibagi 5, jumlahku sekarang " . $angka %= 5;


?>