<?php
for ($i = 1; $i <= 3; $i++) {
    for ($a = 1; $a <= 3; $a++)
echo "Ini Perulangan ke ($i,$a)</br>";
}

?>