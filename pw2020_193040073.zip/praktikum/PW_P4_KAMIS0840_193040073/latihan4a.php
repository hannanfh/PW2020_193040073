<?php
$nama = array("ada", "abel", "men", "pung", "nilai");
$angka = [1,2,3,4,5];

echo "Array $nama[0]lah suatu var$nama[1] yang dapat $nama[2]am$nama[3] banyak $nama[4]";


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>latihan4a</title>
</head>
<style>

</style>
<body>
    
</body>
</html>